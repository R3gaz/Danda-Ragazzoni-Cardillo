﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steganografia
{
    public partial class Form2 : Form
    {
        string frase, percorso;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)      //caricamento immagine
        {
            OpenFileDialog apri = new OpenFileDialog();     //variabile di tipo "carica file"
            apri.Filter = "File immagine(*.jpg; *.jpeg; *.gif; *.png; *.bmp) | *.jpg; *.jpeg; *.gif; *.png; *.bmp";     //filtro per poter inserire solo immagini
            if (apri.ShowDialog() == DialogResult.OK)       //se il caricamento del file avviene con successo
            {
                pictureBox1.Image = new Bitmap(apri.FileName);      //metto l'immagine caricata nella picturebox
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
                MessageBox.Show("Non hai caricato un'immagine!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            else
            {
                if (richTextBox1.Text.Length == 0)
                    MessageBox.Show("Non hai inserito il messaggio!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {
                    frase = richTextBox1.Text;
                    percorso = pictureBox1.ImageLocation;
                    pictureBox1.Image = steganografia(pictureBox1.Image, frase);
                }
            }
        }
        private Image steganografia(Image input, string messaggio)
        {
            int c = 0, c2 = 0, c3;
            int red = 0, green = 0, blue = 0;       //valori interi decimali di rosse verde e blu in un pixel
            int copia = 0;
            int[] binario = new int[8];         //vettore contenente il valore di R, G o B in binario (una cifra per posizione)
            char[] temp = new char[8];          //vettore char temporaneo per conversione
            char[] fraseChar = frase.ToCharArray();         //frase da codificare nell'immagine in vettore char
            int[] fraseInt = new int[fraseChar.Length];         //frase da codificare in intero (valori ascii)
            for (int i = 0; i < fraseChar.Length; i++)
                fraseInt[i] = Convert.ToInt32(fraseChar[i]);        //metto i valori ascii nel vettore intero
            int[] carattereBinario = new int[8];
            int[] fraseInBinario = new int[(fraseChar.Length * 8) + 8];
            int[] eot = { 0, 0, 0, 0, 0, 1, 0, 0 };
            bool finita = false;
            Bitmap output = new Bitmap(input.Width, input.Height);

            for (int y = 0; y < fraseInt.Length; y++)
            {
                temp = decimaleBinario(fraseInt[y]).ToCharArray();
                //MessageBox.Show("valore ascii lettera " + y + ": " + fraseInt[y]);
                for (int k = 0; k < temp.Length; k++)
                {
                    //MessageBox.Show("temp[" + k + "]: " + temp[k]);
                    carattereBinario[k] = Convert.ToInt32(temp[k].ToString());
                    fraseInBinario[c] = carattereBinario[k];
                    c++;
                }
            }
            for (int i = 0; i < 8; i++)
            {
                fraseInBinario[c] = eot[i];
                c++;
            }
            c3 = fraseInBinario.Length;
            int h = 0, w = 0;
            while (h < input.Height && finita == false)
            {
                while (w < input.Width && finita == false)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        if ((c / 8) < frase.Length)
                        {
                            if (k == 0)
                            {
                                Color pixel = (input as Bitmap).GetPixel(w, h);
                                red = pixel.R | 1;
                                temp = decimaleBinario(red).ToCharArray();
                                for (int y = 0; y < binario.Length; y++)
                                {
                                    binario[y] = Convert.ToInt32(temp[y].ToString());
                                }
                                if (c2 < c3)
                                {
                                    binario[7] = fraseInBinario[c2];
                                    c2++;
                                }
                                red = binarioDecimale(binario);
                                pixel = Color.FromArgb(red, pixel.G, pixel.B);
                                output.SetPixel(w, h, pixel);
                            }
                            else if (k == 1)
                            {
                                Color pixel = (input as Bitmap).GetPixel(w, h);
                                green = pixel.G | 1;
                                temp = decimaleBinario(green).ToCharArray();
                                for (int y = 0; y < binario.Length; y++)
                                {
                                    binario[y] = Convert.ToInt32(temp[y].ToString());
                                }
                                if (c2 < c3)
                                {
                                    binario[7] = fraseInBinario[c2];
                                    c2++;
                                }
                                green = binarioDecimale(binario);
                                pixel = Color.FromArgb(pixel.R, green, pixel.B);
                                output.SetPixel(w, h, pixel);
                            }
                            else
                            {
                                Color pixel = (input as Bitmap).GetPixel(w, h);
                                blue = pixel.B | 1;
                                temp = decimaleBinario(blue).ToCharArray();
                                for (int y = 0; y < binario.Length; y++)
                                {
                                    binario[y] = Convert.ToInt32(temp[y].ToString());
                                }
                                if (c2 < c3)
                                {
                                    binario[7] = fraseInBinario[c2];
                                    c2++;
                                }
                                blue = binarioDecimale(binario);
                                pixel = Color.FromArgb(pixel.R, blue, pixel.B);
                                output.SetPixel(w, h, pixel);
                            }
                        }
                        else
                            finita = true;
                    }
                    w++;
                    progressBar1.Value = (h + 1) * progressBar1.Maximum / input.Height;
                }
                h++;
            }
            /*for (int i = 0; i < input.Height; i++)
            {
                for (int j = 0; j < input.Width; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        if (k == 0)
                        {
                            Color pixel = (input as Bitmap).GetPixel(j, i);
                            red = pixel.R | 1;
                            temp = decimaleBinario(red).ToCharArray();
                            for (int y = 0; y < binario.Length; y++)
                            {
                                binario[y] = Convert.ToInt32(temp[y].ToString());
                            }
                            if (c2 < c3)
                            {
                                binario[7] = fraseInBinario[c2];
                                c2++;
                            }
                            red = binarioDecimale(binario);
                            pixel = Color.FromArgb(red, pixel.G, pixel.B);
                            output.SetPixel(j, i, pixel);
                        }
                        else if (k == 1)
                        {
                            Color pixel = (input as Bitmap).GetPixel(j, i);
                            green = pixel.G | 1;
                            temp = decimaleBinario(green).ToCharArray();
                            for (int y = 0; y < binario.Length; y++)
                            {
                                binario[y] = Convert.ToInt32(temp[y].ToString());
                            }
                            if (c2 < c3)
                            {
                                binario[7] = fraseInBinario[c2];
                                c2++;
                            }
                            green = binarioDecimale(binario);
                            pixel = Color.FromArgb(pixel.R, green, pixel.B);
                            output.SetPixel(j, i, pixel);
                        }
                        else
                        {
                            Color pixel = (input as Bitmap).GetPixel(j, i);
                            blue = pixel.B | 1;
                            temp = decimaleBinario(blue).ToCharArray();
                            for (int y = 0; y < binario.Length; y++)
                            {
                                binario[y] = Convert.ToInt32(temp[y].ToString());
                            }
                            if (c2 < c3)
                            {
                                binario[7] = fraseInBinario[c2];
                                c2++;
                            }
                            blue = binarioDecimale(binario);
                            pixel = Color.FromArgb(pixel.R, blue, pixel.B);
                            output.SetPixel(j, i, pixel);
                        }
                    }
                }
                progressBar1.Value = (i + 1) * progressBar1.Maximum / input.Height;
            }*/
            return output;
        }
        private string decimaleBinario(int n)    //convertitore decimale - binario
        {
            int[] temp = new int[8];
            int[] temp2 = new int[8];
            string output;
            for (int i = 0; n > 0; i++)
            {
                temp[i] = n % 2;
                n /= 2;
            }
            int k = 7;
            for (int i = 0; i < temp.Length; i++)
            {
                temp2[i] = temp[k];
                k--;
            }
            output = string.Join("", temp2);
            return output;
        }
        private int binarioDecimale(int[] n)
        {
            int l = 7;
            double p = 0;
            for (int i = 0; i < 8; i++)
            {
                p = p + (n[i] * Math.Pow(2, l));
                l--;
            }
            int x = (int)p;
            return x;
        }
    }
}
